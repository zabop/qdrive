1) Install Anaconda (Jupyter notebooks and many libraries will be automatically installed)

https://www.anaconda.com/distribution/

2) Install Qiskit

https://github.com/Qiskit/qiskit-tutorials/blob/master/INSTALL.md

>>> You might see certain errors during Qiskit installation. If the test notebook (testing IBM connection is not mandatory) will be executed without any problem, then there is no need to worry about these errors.

3) Execute the command "jupyter notebook" under the directory of the tutorial (execute in the command line or write to the address bar and press enter)

4) Start with the notebook "index_bronze.ipynb"

